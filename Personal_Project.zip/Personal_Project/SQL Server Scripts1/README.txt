I did a Office Store (Ex: Office Depot) and how they need supplies from suppliers. I did the connections from what the store needs to stock and what is overstocked to Drivers with Truck IDS so each store has 1 or more Truck ID.

The Address ID, People ID, Store ID, Stock ID, and Truck ID are all identities incrementing at 1, starting with 1.

The Employee ID is the restocker but can also sign if the manager is out or if nobody else can.


